
// YOUR NAME(S) GO HERE! Zhili Zhao
// CS1A - Assignment 3 - "The Maze"
////////////////////////////////////////////////////////////////////////////////
import becker.robots.*;

class MazeBot extends RobotSE {
	// Instance Variables will be declared and initialized here
	// one each for totalMoves, movesWest, movesEast, movesSouth, and MovesNorth

	public MazeBot(City theCity, int str, int ave, Direction dir, int numThings) {
		super(theCity, str, ave, dir, numThings);
	}

	// <-- BIG HINT: You might want to create a new method here called
	// movesCounted() that will count everything it is supposed to by adding to
	// the instance variables before moving, and then use that instead of move()
	// in the NavigateMaze() method
	
	
	
	
//	Function for move
	
	public void moveTest() {
		while(this.getStreet()!=10||this.getAvenue()!=9) {
//			First, check if the left can go 
			this.turnLeft();
			if(this.frontIsClear()) {
				this.move();
				this.countPart(this.getDirection());
				continue;
			}
			this.turnRight();
			
//			Second, check if front can go
			if(this.frontIsClear()) {
				this.move();
				this.countPart(this.getDirection());
				continue;
			}
			
//			Third, check if can go left
			this.turnRight();
			if(this.frontIsClear()) {
				this.countPart(this.getDirection());
				continue;
			}
			
//			Last, if all direction block, turn around
			this.turnRight();
			this.countPart(this.getDirection());
			
		}
		
		//After Arrive to exit point
		this.turnAround();
		System.out.println("Arrive to exit point!");
		System.out.println("- TOTAL NUMBER OF MOVES MADE: "+(northC+southC+westC+eastC)+
				"/n - NUMBER OF TIMES MOVED EAST: "+ eastC
				+ "/n  - NUMBER OF TIMES MOVED SOUTH: "+ southC
				+ "/n  - NUMBER OF TIMES MOVED WEST: " + westC
				+ "/n  - NUMBER OF TIMES MOVED NORTH: "+ northC);


	}
	
	
	
	
//		The countpart
//	Count variables 
		int northC=0;
		int southC=0;
		int westC=0;
		int eastC=0;
		
		public void countPart(Direction dir) {
			switch (dir) {
			case NORTH:
				northC++;
				break;
			case SOUTH:
				southC++;
				break;
			case WEST:
				westC++;
				break;
			case EAST:
				eastC++;
				break;
			}
			
		}
		
 
		
		
//		the function for put things
		
		public void putT() {
			if(this.countThingsInBackpack()!=0&&this.canPickThing()!=true)
				this.putThing();
		}
	
	
	
	
	public void printTotalNumberOfSpacesMoved()// Or printEverything(),
												// whichever you decide
	{

	}

	// The isAtEndSpot() method below is what's called a 'helper method' It
	// exists just to make another command (in this case, NavigateMaze) easier
	// to understand. It does this by replacing some code that otherwise would
	// be in NavigateMaze with it's name, and doing that work here, instead.
	// Declaring it "private" means that only the MazeBot is allowed to call
	// upon it.
	private boolean isAtEndSpot() {
		return getAvenue() == 9 && getStreet() == 10;
	}

	// THIS IS THE ONE MAIN METHOD WILL DO EVERYTHING (ALTHOUGH IT CAN USE OTHER
	// METHODS LIKE isAtEndSpot, ETC)
	public void navigateMaze() {
		while(this.getStreet()!=10||this.getAvenue()!=9) {
//			First, check if the left can go 
			this.turnLeft();
			if(this.frontIsClear()) {
				this.putT();
				this.move();
				this.countPart(this.getDirection());
				continue;
			}
			this.turnRight();
			
//			Second, check if front can go
			if(this.frontIsClear()) {
				this.putT();
				this.move();
				this.countPart(this.getDirection());
				continue;
			}
			
//			Third, check if can go left
			this.turnRight();
			if(this.frontIsClear()) {
				this.countPart(this.getDirection());
				continue;
			}
			
//			Last, if all direction block, turn around
			this.countPart(this.getDirection());
			this.turnRight();
			
		}
		
		//After Arrive to exit point
		this.turnAround();
		System.out.println("Arrive to exit point!");
		System.out.println("- TOTAL NUMBER OF MOVES MADE: "+(northC+southC+westC+eastC));
		System.out.println("- NUMBER OF TIMES MOVED EAST: "+ eastC);
		System.out.println("- NUMBER OF TIMES MOVED SOUTH: "+ southC);
		System.out.println("- NUMBER OF TIMES MOVED WEST: " + westC);
		System.out.println("- NUMBER OF TIMES MOVED NORTH: "+ northC);

		// While your robot hasn't yet reached the 'end spot', keep navigating
		// through the Maze and doing its thing
		
		while (!isAtEndSpot()) {
			
			// The robot will navigate the Maze until it gets to the end spot.
			// What will you have the robot do at each step?
		}

		// After completing Maze, print total number of spaces moved and how
		// many times robot moved East, South, West, North.
	}

}

// ###################################################################################################
// NO NEED TO TOUCH ANYTHING FROM HERE ON DOWN, EXCEPT TO CHANGE NUMBER OF
// THINGS IN BACKPACK IN MAIN
// The NavigateMaze() method is already set up and called by don the robot down
// in main
// ###################################################################################################
public class Maze extends Object {
	private static void makeMaze(City theCity) {
		for (int i = 1; i < 11; i++) {
			// north wall
			new Wall(theCity, 1, i, Direction.NORTH);

			// Second to north wall
			if (i <= 9)
				new Wall(theCity, 1, i, Direction.SOUTH);

			// Third to north wall
			if (i >= 4)
				new Wall(theCity, 4, i, Direction.SOUTH);

			// south wall
			if (i != 9) // (9, 10, SOUTH), is where the 'exit' is
				new Wall(theCity, 10, i, Direction.SOUTH);

			// west wall
			if (i != 1) // (1,1, WEST) is where the 'entrance' is
				new Wall(theCity, i, 1, Direction.WEST);

			// second to west-most wall
			if (i >= 3 && i < 6)
				new Wall(theCity, i, 6, Direction.WEST);

			// east wall
			new Wall(theCity, i, 10, Direction.EAST);
		}

		// cul-de-sac
		new Wall(theCity, 3, 10, Direction.WEST);
		new Wall(theCity, 3, 10, Direction.SOUTH);

		new Wall(theCity, 2, 8, Direction.WEST);
		new Wall(theCity, 2, 8, Direction.SOUTH);

		new Wall(theCity, 10, 8, Direction.NORTH);
		new Wall(theCity, 10, 9, Direction.EAST);
		new Wall(theCity, 10, 9, Direction.NORTH);
		makeSpiral(theCity, 8, 9, 3);
		new Wall(theCity, 8, 10, Direction.SOUTH);

		makeSpiral(theCity, 10, 5, 4);
	}

	public static void makeSpiral(City theCity, int st, int ave, int size) {
		// We start out building the wall northward
		// the walls will be built on the east face of the current
		// intersection
		Direction facing = Direction.EAST;

		while (size > 0) {
			int spacesLeft = size;
			int aveChange = 0;
			int stChange = 0;
			switch (facing) {
			case EAST:
				stChange = -1;
				break;
			case NORTH:
				aveChange = -1;
				break;
			case WEST:
				stChange = 1;
				break;
			case SOUTH:
				aveChange = 1;
				break;
			}

			while (spacesLeft > 0) {
				new Wall(theCity, st, ave, facing);
				ave += aveChange;
				st += stChange;
				--spacesLeft;
			}
			// back up one space
			ave -= aveChange;
			st -= stChange;

			switch (facing) {
			case EAST:
				facing = Direction.NORTH;
				break;
			case NORTH:
				facing = Direction.WEST;
				size--;
				break;
			case WEST:
				facing = Direction.SOUTH;
				break;
			case SOUTH:
				facing = Direction.EAST;
				size--;
				break;
			}
		}
	}

	// ###########################################################################################
	// Main Method
	// ###########################################################################################
	public static void main(String[] args) {
		City calgary = new City(12, 12);
		MazeBot don = new MazeBot(calgary, 1, 1, Direction.EAST, 100); // <-- YOU
																		// WILL
																		// NEED
																		// TO
																		// CHANGE
																		// THIS
																		// FROM
																		// ZERO

		Maze.makeMaze(calgary);

		don.navigateMaze(); // <-- HERE'S WHERE THE NavigateMaze() method is
							// called. NO NEED TO TOUCH AT ALL

	}
}
